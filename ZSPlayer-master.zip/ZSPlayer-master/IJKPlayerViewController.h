//
//  IJKPlayerViewController.h
//  LWDPlayer
//
//  Created by liweidong on 17/7/30.
//  Copyright © 2017年 Sillen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IJKPlayerViewController : UIViewController
@property(nonatomic,copy)NSString * url;//视频推流地址
@property(nonatomic,copy)NSString * titleStr;//视频标题
@end
