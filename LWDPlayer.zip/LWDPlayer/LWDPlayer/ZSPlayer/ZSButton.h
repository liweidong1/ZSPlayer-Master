//
//  ZSButton.h
//  testButton
//
//  Created by zsj1992 on 16/12/27.
//  Copyright © 2016年 zsj1992 All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZSButton : UIButton

@end
