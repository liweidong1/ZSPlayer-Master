//
//  ZSLoading.h
//  testLoading
//
//  Created by zsj1992 on 16/12/28.
//  Copyright © 2016年 zsj1992 All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZSLoading : UIView
@property(nonatomic,assign)BOOL firstSetFrame;
@property (nonatomic,assign) BOOL animationStop;
@end
