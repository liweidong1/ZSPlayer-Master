//
//  ViewController.m
//  LWDPlayer
//
//  Created by liweidong on 17/7/30.
//  Copyright © 2017年 Sillen. All rights reserved.
//

#import "ViewController.h"
#import "IJKPlayerViewController.h"


@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}
- (IBAction)player:(id)sender {
    IJKPlayerViewController *ijkVC =[[IJKPlayerViewController alloc]init];
    //MP4:https://bmob-cdn-11424.b0.upaiyun.com/2017/07/28/11455c1d6a674b3488144cf701a0ca8f.mp4
    //直播流:http://hls.quanmin.tv/live/4112828/playlist.m3u8
    NSString *mp4Str =@"https://bmob-cdn-11424.b0.upaiyun.com/2017/07/28/11455c1d6a674b3488144cf701a0ca8f.mp4";
    NSString *m3u8Str = @"http://hls.quanmin.tv/live/326745/playlist.m3u8";
    ijkVC.url = m3u8Str;
    ijkVC.titleStr = @"我是标题";
    self.navigationController.navigationBar.hidden = YES;
    [self.navigationController pushViewController:ijkVC animated:YES];
    
}



@end
